# CampusKhoj — College Project Report

## Project Title
CampusKhoj: College Lost and Found Portal

## Introduction
CampusKhoj is a web-based demo for one college. Students can post items they lost or found, browse reports, filter by category, and contact the reporter.

## Problem Statement
Lost-item information is often scattered across class groups and word of mouth. A single searchable portal can make it easier for students to find relevant reports.

## Objectives
- Create a central place for lost and found reports.
- Search by item name, location, category, or description.
- Show item date, location, and description.
- Provide email and WhatsApp contact links.
- Demonstrate responsive HTML, CSS, and JavaScript.

## Technology Used
- HTML5 — page structure and report form
- CSS3 — responsive styling
- JavaScript — form handling, search, filters, and contact links
- localStorage — stores demo reports in the current browser

## Main Modules
1. Dashboard and report counts
2. Lost/Found report form
3. Search and category/type filters
4. Email/WhatsApp contact actions
5. Browser-local data persistence

## How to Run
1. Extract the project ZIP.
2. Open `index.html` in a modern browser.
3. Post a test report and try the search/filter options.

No package installation is required.

## Limitations
This is a front-end demo. Reports are stored only in the current browser and are not shared between students/devices. Demo contacts are illustrative. The project has no login, central database, admin moderation, or photo uploads.

## Future Scope
- Add Firebase or Supabase for shared reports.
- Add college email authentication.
- Add image uploads and item-return status.
- Add admin moderation and privacy controls.

## Conclusion
CampusKhoj demonstrates a simple digital workflow for campus lost-and-found reporting. A shared backend and privacy protections would be required for real college-wide use.

## Updated features
- Hindi and English language toggle.
- Built-in icon selection and custom emoji/symbol entry when posting a report.
