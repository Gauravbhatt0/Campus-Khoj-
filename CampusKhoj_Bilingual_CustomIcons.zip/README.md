# CampusKhoj 🎓🔎

CampusKhoj is a responsive Lost & Found website demo for a single college. Students can report lost or found items, search/filter reports, and contact reporters by email or WhatsApp.

## Features
- Lost and Found report forms
- Hindi / English language switch (selection is remembered in this browser)
- Built-in icon picker plus a custom emoji/symbol field for each report
- Search by item name, location, category, or description
- Filters for report type and category
- Contact buttons for email and WhatsApp
- Responsive design for phones and computers
- Sample reports for project demonstration
- Reports saved in the current browser with `localStorage`

## Run locally
Extract this ZIP and open `index.html` in a modern browser. No build tools or package installation are required.

## Publish on GitHub Pages
1. Create a GitHub repository named `CampusKhoj`.
2. Upload the contents of this folder to the repository root. Upload `index.html`, `css/`, `js/`, and the Markdown files—not the ZIP itself.
3. Open **Settings → Pages**.
4. Select **Deploy from a branch**, branch `main`, folder `/(root)`, then save.
5. Wait for GitHub Pages to publish and use the URL shown in the Pages settings.

## Demo limitation
Reports are stored only in the same browser/device. Students using other devices will not see them. Sample contact details are illustrative. A real college-wide version needs a shared database (such as Firebase or Supabase), authentication, moderation, and privacy controls.

See [PROJECT_REPORT.md](PROJECT_REPORT.md) for the college project report.
